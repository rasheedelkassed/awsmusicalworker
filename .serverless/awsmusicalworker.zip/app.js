const express = require('serverless-express/express')
var app = express();

module.exports = app